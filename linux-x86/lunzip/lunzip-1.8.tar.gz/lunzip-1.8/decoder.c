/*  Lunzip - Decompressor for the lzip format
    Copyright (C) 2010-2016 Antonio Diaz Diaz.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#define _FILE_OFFSET_BITS 64

#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "lzip.h"
#include "decoder.h"


CRC32 crc32;


void Pp_show_msg( struct Pretty_print * const pp, const char * const msg )
  {
  if( verbosity >= 0 )
    {
    if( pp->first_post )
      {
      unsigned i;
      pp->first_post = false;
      fprintf( stderr, "  %s: ", pp->name );
      for( i = strlen( pp->name ); i < pp->longest_name; ++i )
        fputc( ' ', stderr );
      if( !msg ) fflush( stderr );
      }
    if( msg ) fprintf( stderr, "%s\n", msg );
    }
  }


/* Returns the number of bytes really read.
   If (returned value < size) and (errno == 0), means EOF was reached.
*/
static int readblock( const int fd, uint8_t * const buf, const int size )
  {
  int sz = 0;
  errno = 0;
  while( sz < size )
    {
    const int n = read( fd, buf + sz, size - sz );
    if( n > 0 ) sz += n;
    else if( n == 0 ) break;				/* EOF */
    else if( errno != EINTR ) break;
    errno = 0;
    }
  return sz;
  }


/* Returns the number of bytes really written.
   If (returned value < size), it is always an error.
*/
static int writeblock( const int fd, const uint8_t * const buf, const int size )
  {
  int sz = 0;
  errno = 0;
  while( sz < size )
    {
    const int n = write( fd, buf + sz, size - sz );
    if( n > 0 ) sz += n;
    else if( n < 0 && errno != EINTR ) break;
    errno = 0;
    }
  return sz;
  }


int seek_read( const int fd, uint8_t * const buf, const int size,
               const int offset )
  {
  if( lseek( fd, offset, SEEK_END ) >= 0 )
    return readblock( fd, buf, size );
  return 0;
  }


bool Rd_read_block( struct Range_decoder * const rdec )
  {
  if( !rdec->at_stream_end )
    {
    rdec->stream_pos = readblock( rdec->infd, rdec->buffer, rd_buffer_size );
    if( rdec->stream_pos != rd_buffer_size && errno )
      { show_error( "Read error", errno, false ); cleanup_and_fail( 1 ); }
    rdec->at_stream_end = ( rdec->stream_pos < rd_buffer_size );
    rdec->partial_member_pos += rdec->pos;
    rdec->pos = 0;
    }
  return rdec->pos < rdec->stream_pos;
  }


void LZd_flush_data( struct LZ_decoder * const d )
  {
  if( d->pos > d->stream_pos )
    {
    const int size = d->pos - d->stream_pos;
    CRC32_update_buf( &d->crc, d->buffer + d->stream_pos, size );
    if( d->outfd >= 0 &&
        writeblock( d->outfd, d->buffer + d->stream_pos, size ) != size )
      { show_error( "Write error", errno, false ); cleanup_and_fail( 1 ); }
    if( d->pos >= d->buffer_size )
      { d->partial_data_pos += d->pos; d->pos = 0;
        if( d->partial_data_pos >= d->dictionary_size ) d->pos_wrapped = true; }
    d->stream_pos = d->pos;
    }
  }


static bool LZd_verify_trailer( struct LZ_decoder * const d,
                                struct Pretty_print * const pp )
  {
  File_trailer trailer;
  int size = Rd_read_data( d->rdec, trailer, Ft_size );
  const unsigned long long data_size = LZd_data_position( d );
  const unsigned long long member_size = Rd_member_position( d->rdec );
  bool error = false;

  if( size < Ft_size )
    {
    error = true;
    if( verbosity >= 0 )
      {
      Pp_show_msg( pp, 0 );
      fprintf( stderr, "Trailer truncated at trailer position %d;"
                       " some checks may fail.\n", size );
      }
    while( size < Ft_size ) trailer[size++] = 0;
    }

  if( Ft_get_data_crc( trailer ) != LZd_crc( d ) )
    {
    error = true;
    if( verbosity >= 0 )
      {
      Pp_show_msg( pp, 0 );
      fprintf( stderr, "CRC mismatch; trailer says %08X, data CRC is %08X\n",
               Ft_get_data_crc( trailer ), LZd_crc( d ) );
      }
    }
  if( Ft_get_data_size( trailer ) != data_size )
    {
    error = true;
    if( verbosity >= 0 )
      {
      Pp_show_msg( pp, 0 );
      fprintf( stderr, "Data size mismatch; trailer says %llu, data size is %llu (0x%llX)\n",
               Ft_get_data_size( trailer ), data_size, data_size );
      }
    }
  if( Ft_get_member_size( trailer ) != member_size )
    {
    error = true;
    if( verbosity >= 0 )
      {
      Pp_show_msg( pp, 0 );
      fprintf( stderr, "Member size mismatch; trailer says %llu, member size is %llu (0x%llX)\n",
               Ft_get_member_size( trailer ), member_size, member_size );
      }
    }
  if( !error && verbosity >= 2 && data_size > 0 && member_size > 0 )
    fprintf( stderr, "%6.3f:1, %6.3f bits/byte, %5.2f%% saved.  ",
             (double)data_size / member_size,
             ( 8.0 * member_size ) / data_size,
             100.0 * ( 1.0 - ( (double)member_size / data_size ) ) );
  if( !error && verbosity >= 4 )
    fprintf( stderr, "data CRC %08X, data size %9llu, member size %8llu.  ",
             LZd_crc( d ), data_size, member_size );
  return !error;
  }


/* Return value: 0 = OK, 1 = decoder error, 2 = unexpected EOF,
                 3 = trailer error, 4 = unknown marker found. */
int LZd_decode_member( struct LZ_decoder * const d,
                       struct Pretty_print * const pp )
  {
  struct Range_decoder * const rdec = d->rdec;
  void (* const copy_block)
       ( struct LZ_decoder * const d, const int distance, int len ) =
    ( (unsigned)d->buffer_size >= d->dictionary_size ) ?
    &LZd_copy_block : &LZd_copy_block2;
  unsigned rep0 = 0;		/* rep[0-3] latest four distances */
  unsigned rep1 = 0;		/* used for efficient coding of */
  unsigned rep2 = 0;		/* repeated distances */
  unsigned rep3 = 0;
  State state = 0;

  Rd_load( rdec );
  while( !Rd_finished( rdec ) )
    {
    const int pos_state = LZd_data_position( d ) & pos_state_mask;
    if( Rd_decode_bit( rdec, &d->bm_match[state][pos_state] ) == 0 )	/* 1st bit */
      {
      const uint8_t prev_byte = LZd_peek_prev( d );
      if( St_is_char( state ) )
        {
        state -= ( state < 4 ) ? state : 3;
        LZd_put_byte( d, Rd_decode_tree( rdec,
                         d->bm_literal[get_lit_state(prev_byte)], 8 ) );
        }
      else
        {
        state -= ( state < 10 ) ? 3 : 6;
        LZd_put_byte( d, Rd_decode_matched( rdec,
                         d->bm_literal[get_lit_state(prev_byte)],
                         LZd_peek( d, rep0 ) ) );
        }
      }
    else					/* match or repeated match */
      {
      int len;
      if( Rd_decode_bit( rdec, &d->bm_rep[state] ) != 0 )	/* 2nd bit */
        {
        if( Rd_decode_bit( rdec, &d->bm_rep0[state] ) != 0 )	/* 3rd bit */
          {
          unsigned distance;
          if( Rd_decode_bit( rdec, &d->bm_rep1[state] ) == 0 )	/* 4th bit */
            distance = rep1;
          else
            {
            if( Rd_decode_bit( rdec, &d->bm_rep2[state] ) == 0 )	/* 5th bit */
              distance = rep2;
            else
              { distance = rep3; rep3 = rep2; }
            rep2 = rep1;
            }
          rep1 = rep0;
          rep0 = distance;
          }
        else
          {
          if( Rd_decode_bit( rdec, &d->bm_len[state][pos_state] ) == 0 )	/* 4th bit */
            { state = St_set_short_rep( state );
              LZd_put_byte( d, LZd_peek( d, rep0 ) ); continue; }
          }
        state = St_set_rep( state );
        len = min_match_len + Rd_decode_len( rdec, &d->rep_len_model, pos_state );
        }
      else					/* match */
        {
        int dis_slot;
        const unsigned rep0_saved = rep0;
        len = min_match_len + Rd_decode_len( rdec, &d->match_len_model, pos_state );
        dis_slot = Rd_decode_tree6( rdec, d->bm_dis_slot[get_len_state(len)] );
        if( dis_slot < start_dis_model ) rep0 = dis_slot;
        else
          {
          const int direct_bits = ( dis_slot >> 1 ) - 1;
          rep0 = ( 2 | ( dis_slot & 1 ) ) << direct_bits;
          if( dis_slot < end_dis_model )
            rep0 += Rd_decode_tree_reversed( rdec,
                    d->bm_dis + rep0 - dis_slot - 1, direct_bits );
          else
            {
            rep0 += Rd_decode( rdec, direct_bits - dis_align_bits ) << dis_align_bits;
            rep0 += Rd_decode_tree_reversed4( rdec, d->bm_align );
            if( rep0 == 0xFFFFFFFFU )		/* marker found */
              {
              rep0 = rep0_saved;
              Rd_normalize( rdec );
              LZd_flush_data( d );
              if( len == min_match_len )	/* End Of Stream marker */
                {
                if( LZd_verify_trailer( d, pp ) ) return 0; else return 3;
                }
              if( len == min_match_len + 1 )	/* Sync Flush marker */
                {
                Rd_load( rdec ); continue;
                }
              if( verbosity >= 0 )
                {
                Pp_show_msg( pp, 0 );
                fprintf( stderr, "Unsupported marker code '%d'\n", len );
                }
              return 4;
              }
            }
          }
        rep3 = rep2; rep2 = rep1; rep1 = rep0_saved;
        state = St_set_match( state );
        if( rep0 >= d->dictionary_size ||
            ( rep0 >= LZd_data_position( d ) && !d->pos_wrapped ) )
          { LZd_flush_data( d ); return 1; }
        }
      copy_block( d, rep0, len );
      }
    }
  LZd_flush_data( d );
  return 2;
  }
